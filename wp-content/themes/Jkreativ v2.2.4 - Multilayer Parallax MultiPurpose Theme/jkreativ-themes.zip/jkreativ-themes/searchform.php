<form method="get" action="<?php echo home_url(); ?>/">
	<input type="text" autocomplete="off" name="s" placeholder="<?php _e('Type and Enter to Search', 'jeg_textdomain'); ?>">
</form>