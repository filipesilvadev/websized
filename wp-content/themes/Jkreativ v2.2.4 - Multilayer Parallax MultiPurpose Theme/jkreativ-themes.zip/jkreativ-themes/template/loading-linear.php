<div id="loading" data-type="linear">
	<div class="loadingwrapper">
		<div class="percentage"><span>0%</span></div>
		<div class="line"></div>
	</div>
</div>