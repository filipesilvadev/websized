<div class="blog-fb-likebox">
<div class="fb-like-box" data-href="<?php echo $facebookurl; ?>" data-width="292" data-height="300" data-show-faces="true" data-header="false" data-stream="false" data-show-border="true"></div>
</div>