<p>
	<label for="<?php echo $fieldid; ?>"><?php echo $title  ?></label> 
	<input class="widefat" id="<?php echo $fieldid ?>" name="<?php echo $fieldname ?>" type="text" value="<?php echo $value ?>" />
	<i><?php echo $desc ?></i>
</p>